# Lidar Cluster

This ROS package is an open source version of lidar_cluster from BITFSD. We removed some components to keep it simple but it still has great performance.  

## Algorithm

The core idea of this algorithm is euclidean clustering. First, we filter out the point clouds on the ground, and filter out the point clouds that meet the feature of the cones, then cluster them.

## Important Dependencies

* ROS

* PCL

  * 安装教程参考：[Ubuntu18.04下安装点云库PCL1.9.0](https://blog.csdn.net/czychen1997/article/details/107306674)，[Ubuntu18.04安装PCL（详细教程）](https://blog.csdn.net/weixin_45629790/article/details/112547011?utm_medium=distribute.pc_relevant.none-task-blog-2%7Edefault%7EBlogCommendFromMachineLearnPai2%7Edefault-1.control&dist_request_id=&depth_1-utm_source=distribute.pc_relevant.none-task-blog-2%7Edefault%7EBlogCommendFromMachineLearnPai2%7Edefault-1.control)

  * 首先安装[metslib-0.5.3](https://www.coin-or.org/download/source/metslib/metslib-0.5.3.tgz) ，[VTK-8.2.0.tar.gz](https://www.vtk.org/files/release/8.2/VTK-8.2.0.tar.gz) 这两个库。

  * 如果遇到下面这个问题，那就是Qt版本太高了，重新下载Qt5.0-5.5都可！

    ```bash
     Could not find a package configuration file provided by "Qt5WebKitWidgets"
      with any of the following names:
    Qt5WebKitWidgetsConfig.cmake
    qt5webkitwidgets-config.cmake
    ```

---

## ROS topic:

* subscriber:
  - /velodyne_points (sensor_msgs/PointCloud2)
* publisher:	
  - /perception/lidar_cluster (sensor_msgs/PointCloud)

---

# Key parameters

All parameters are set in the `./config/lidar_cluster.yaml` 

## Prerequisites

You need a LiDAR sensor to generate point clouds.

## Step

* Move package to your workspace.
* Go to your workspace,  `catkin build`
* `source devel/setup.bash`
* `roslaunch lidar_cluster lidar_cluster.launch`