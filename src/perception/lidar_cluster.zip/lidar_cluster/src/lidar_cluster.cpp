/*
    Formula Student Driverless Project (FSD-Project).
    Copyright (c) 2019:
     - chentairan <killasipilin@gmail.com>

    FSD-Project is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FSD-Project is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FSD-Project.  If not, see <https://www.gnu.org/licenses/>.
*/

#include "lidar_cluster.hpp"
#include <ros/ros.h>
#include <sstream>
#include <fstream>
#include <utility>

namespace ns_lidar_cluster {
// Constructor
LidarCluster::LidarCluster(ros::NodeHandle &nh) : nh_(nh) { loadParameters(); 
  };

// load Param
void LidarCluster::loadParameters() {
  getRawLidar_ = false;
  is_ok_flag_ = false;
  nh_.param("fitting_size",fitting_size_,6);
}

// Getters
sensor_msgs::PointCloud LidarCluster::getLidarCluster() { return cluster_; 
    }

sensor_msgs::PointCloud LidarCluster::getCenterPoints() { return center_points_; }

sensor_msgs::PointCloud2 LidarCluster::getFilterCones() { return filter_cones_; }

sensor_msgs::PointCloud2 LidarCluster::getFilterGround() { return filter_ground_; }

sensor_msgs::PointCloud2 LidarCluster::getFilterRaw() { return filter_raw_; }

sensor_msgs::PointCloud2 LidarCluster::getClusterCones() { return cone_; }

bool LidarCluster::is_ok() const { return is_ok_flag_; }

// Setters
void LidarCluster::setRawLidar(const sensor_msgs::PointCloud2 &msg) {
  raw_pc2_ = msg;
  getRawLidar_ = true;
}

void LidarCluster::runAlgorithm() {
  if (raw_pc2_.fields.empty() || !getRawLidar_) {
    return;
  }
  getRawLidar_ = false;

  pcl::fromROSMsg(raw_pc2_, raw_pc_);

  // 
  std::vector<int>  rm_indices; //保存去除的点的索引
  raw_pc_.is_dense = false;
  pcl::removeNaNFromPointCloud(raw_pc_, raw_pc_, rm_indices);


  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_ground(
      new pcl::PointCloud<pcl::PointXYZI>);
  pcl::PointCloud<pcl::PointXYZI>::Ptr cloud_cones(
      new pcl::PointCloud<pcl::PointXYZI>);


  // segment the groud point cloud and get the raw_flatten
  preprocessing(raw_pc_, cloud_ground, cloud_cones);

  // use cluster and multi filter to get the cones position
  ClusterProcessing(cloud_cones, 0.5);

  cluster_.header.frame_id = "/laser_link";
  cluster_.header.stamp = raw_pc2_.header.stamp;
  is_ok_flag_ = true;
}

void LidarCluster::preprocessing(
    pcl::PointCloud<pcl::PointXYZI> &raw,
    pcl::PointCloud<pcl::PointXYZI>::Ptr &cloud_ground,
    pcl::PointCloud<pcl::PointXYZI>::Ptr &cloud_cones) {

  pcl::PointCloud<pcl::PointXYZI> filtered;

  for (auto &iter : raw.points) {
    if (std::hypot(iter.x, iter.y) < sqrt(4) || iter.z > 0.7 ||
        iter.x < -1 || std::abs(iter.y) > 3.5 ||std::hypot(iter.x, iter.y) > 25 )
        //(std::hypot(iter.x, iter.y) > 7 && iter.z < 0.03)||
      continue;
    filtered.points.push_back(iter);
  }
  filtered.width = filtered.points.size();
  filtered.height = 1;
  filtered.is_dense = false ;
  //debug
  // pcl::io::savePCDFileASCII("/home/shawn/perception_v1.1/filtered.pcd" , filtered);
  
  pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
  pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
  // Create the segmentation object
  pcl::SACSegmentation<pcl::PointXYZI> seg;
  // Optional
  seg.setOptimizeCoefficients(true);
  // Mandatory
  seg.setModelType(pcl::SACMODEL_PLANE);
  seg.setMethodType(pcl::SAC_RANSAC);
  // set Distance Threshold
  seg.setDistanceThreshold(0.07);//0.07
  seg.setInputCloud(filtered.makeShared());
  seg.segment(*inliers, *coefficients);
  
  // extract ground
  pcl::ExtractIndices<pcl::PointXYZI> extract;
  extract.setInputCloud(filtered.makeShared());
  extract.setIndices(inliers);
  extract.filter(*cloud_ground);

  // extract cone
  extract.setNegative(true);
  extract.filter(*cloud_cones);

  pcl::toROSMsg(*cloud_ground, filter_ground_);
  pcl::toROSMsg(*cloud_cones, filter_cones_);
  filter_ground_.header.frame_id = "/laser_link";
  filter_ground_.header.stamp = ros::Time::now();
  filter_cones_.header.frame_id = "/laser_link";
  filter_cones_.header.stamp = ros::Time::now(); 
  // pcl::io::savePCDFileASCII("/home/shawn/perception_v1.1/cloud_ground.pcd" , *cloud_ground);
  // pcl::io::savePCDFileASCII("/home/shawn/perception_v1.1/cloud_cones.pcd" , *cloud_cones);
}

void LidarCluster::ClusterProcessing(
    const pcl::PointCloud<pcl::PointXYZI>::Ptr &cloud, double threshold) {

  cluster_.points.clear();

  // Creating the KdTree object for the search method of the extraction
  pcl::search::KdTree<pcl::PointXYZI>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZI>);
  tree->setInputCloud(cloud);

  std::vector<pcl::PointIndices> cluster_indices;
  pcl::EuclideanClusterExtraction<pcl::PointXYZI> ec;
  ec.setClusterTolerance(threshold);
  ec.setMinClusterSize(2);
  ec.setMaxClusterSize(1000);
  ec.setSearchMethod(tree);
  ec.setInputCloud(cloud);
  ec.extract(cluster_indices);
   
  pcl::PointCloud<pcl::PointXYZI>::Ptr cluster_cone(new pcl::PointCloud<pcl::PointXYZI>);

  for (const auto &iter : cluster_indices) {
    pcl::PointCloud<pcl::PointXYZI>::Ptr cone(new pcl::PointCloud<pcl::PointXYZI>);
    for (auto it : iter.indices) {
      cone->points.push_back(cloud->points[it]);
      cluster_cone->points.push_back(cloud->points[it]);
    }
    cone->width = cone->points.size();
    cone->height = 1;
    cone->is_dense = true;
    
    Eigen::Vector4f centroid;
    Eigen::Vector4f min;
    Eigen::Vector4f max;
    pcl::compute3DCentroid(*cone, centroid);
    pcl::getMinMax3D(*cone, min, max);

    float bound_x = std::fabs(max[0] - min[0]);
    float bound_y = std::fabs(max[1] - min[1]);
    float bound_z = std::fabs(max[2] - min[2]);

    // filter based on the shape of cones
    if (bound_x < 0.5 && bound_y < 0.5 && bound_z < 0.4 && centroid[2] < 0.4) {
      geometry_msgs::Point32 tmp;
      tmp.x = centroid[0];
      tmp.y = centroid[1];
      tmp.z = centroid[2];
      cluster_.points.push_back(tmp);
    }

  }

    if (!is_init && cluster_.points.size() == fitting_size_) {
      center_points_ = cluster_;
      is_init = true;
    }

    cluster_cone->width = cluster_cone->points.size();
    cluster_cone->height = 1;
    cluster_cone->is_dense = true;
    pcl::toROSMsg(*cluster_cone, cone_);
    cone_.header.frame_id = "/laser_link";
    cone_.header.stamp = ros::Time::now();
}

} // namespace ns_lidar_cluster
